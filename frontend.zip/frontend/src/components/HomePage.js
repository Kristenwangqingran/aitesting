import React from 'react';
import './HomePage.css'; // 引入样式

const HomePage = () => {
  return (
    <div className="home-page">
      <h1 className="main-title">欢迎来到首页！</h1>
    </div>
  );
};

export default HomePage;
