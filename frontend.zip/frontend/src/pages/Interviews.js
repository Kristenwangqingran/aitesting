// src/pages/Interviews.js
import React from 'react';

function Interviews() {
  return (
    <div>
      <h1>大厂面试</h1>
      <p>这里是大厂面试的内容。</p>
    </div>
  );
}

export default Interviews;
