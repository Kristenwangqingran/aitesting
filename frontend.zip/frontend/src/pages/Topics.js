// src/pages/Topics.js
import React from 'react';

function Topics() {
  return (
    <div>
      <h1>架构专题</h1>
      <p>这里是架构专题的内容。</p>
    </div>
  );
}

export default Topics;
