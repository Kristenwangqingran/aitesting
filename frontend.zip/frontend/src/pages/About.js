// src/pages/About.js
import React from 'react';

function About() {
  return (
    <div>
      <h1>关于</h1>
      <p>这是关于页面的内容。</p>
    </div>
  );
}

export default About;
