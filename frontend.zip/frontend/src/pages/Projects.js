// src/pages/Projects.js
import React from 'react';

function Projects() {
  return (
    <div>
      <h1>项目实战</h1>
      <p>这里是项目实战的内容。</p>
    </div>
  );
}

export default Projects;
